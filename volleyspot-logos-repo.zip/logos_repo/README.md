# volleyspot-logos

Logos des clubs de volley-ball affichés dans [VolleySpot](https://github.com/), hébergés ici et servis via [jsDelivr](https://www.jsdelivr.com/) pour garder le fichier HTML principal léger (les logos étaient auparavant encodés en base64 directement dans le HTML, +3,2 Mo).

## Structure

```
logos/
  0750001.jpg
  0750039.png
  ...
manifest.json
```

Chaque fichier est nommé `{numero_affiliation_ffvolley}.{ext}` — le numéro à 7 chiffres correspond à l'identifiant FFVolley du club (même valeur que la clé utilisée dans `CLUB_LOGOS` côté HTML, sans le préfixe `club_`).

`manifest.json` liste tous les logos avec leur nom de fichier et leur poids en octets — utile pour vérifier qu'aucun logo n'a été perdu lors d'une resynchro.

## Utilisation dans VolleySpot

Une fois ce repo poussé sur GitHub sous `{USERNAME}/volleyspot-logos`, chaque logo est accessible via jsDelivr à :

```
https://cdn.jsdelivr.net/gh/{USERNAME}/volleyspot-logos@main/logos/{club_id}.{ext}
```

Le code du HTML (`CLUB_LOGOS`) doit être mis à jour pour pointer vers ces URLs au lieu du base64 embarqué — cette étape est prête côté script mais nécessite l'URL réelle du repo pour être appliquée.

## Mise à jour d'un logo

1. Remplacer le fichier correspondant dans `logos/` (garder le même nom `{club_id}.{ext}`)
2. Mettre à jour `manifest.json` si la taille a changé (optionnel, informatif)
3. Commit + push — jsDelivr peut mettre jusqu'à 24h à rafraîchir son cache CDN pour la branche `@main` ; pour une mise à jour immédiate, référencer un tag de version au lieu de `@main` (ex: `@v1.0.1`)

## Origine des données

Logos issus de maillots de clubs fournis par l'utilisateur, recadrés, associés au numéro d'affiliation FFVolley du club correspondant.
